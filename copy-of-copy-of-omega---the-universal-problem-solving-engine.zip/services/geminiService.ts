import { GoogleGenAI, Type, Chat } from "@google/genai";
import type { ProblemDeconstruction, Hypothesis, Debate, Solution, ChatMessage } from '../types';
import { OMEGA_MASTER_PROMPT } from '../constants';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const deconstructProblem = async (problem: string): Promise<ProblemDeconstruction> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `${OMEGA_MASTER_PROMPT}\n\n**Current Task**: Execute STAGE 1: ANALYSIS / DECONSTRUCTION for the following problem: "${problem}". Deconstruct it into its core components. Output a JSON object with keyVariables, constraints, desiredOutcomes, and the primary knowledgeFields required.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          keyVariables: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The key variables and factors that influence the problem." },
          constraints: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Limitations, challenges, or boundaries that must be considered." },
          desiredOutcomes: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The specific, measurable goals of a successful solution." },
          knowledgeFields: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The primary scientific or technical fields relevant to solving the problem." },
        },
        required: ['keyVariables', 'constraints', 'desiredOutcomes', 'knowledgeFields'],
      },
    },
  });
  return JSON.parse(response.text);
};

export const generateHypotheses = async (problem: string, deconstruction: ProblemDeconstruction): Promise<Hypothesis[]> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `${OMEGA_MASTER_PROMPT}\n\n**Current Task**: Execute STAGE 2: HYPOTHESIS GENERATION for the problem: "${problem}".\nProblem Deconstruction for context: ${JSON.stringify(deconstruction)}\n\nGenerate exactly three diverse and actionable hypotheses from the perspectives of your core agents:\n1. A 'Scientific' hypothesis from Dr. Elara.\n2. An 'Engineering' hypothesis from Kairo.\n3. A 'Policy' or 'Social' hypothesis from Riva, focused on impact.\n\nFor each, provide a unique ID (1, 2, 3), its type, a title, a brief description, a confidence score (0-100) as determined by Dr. Orion, and an estimate of required resources.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            type: { type: Type.STRING, enum: ['Scientific', 'Engineering', 'Policy', 'Social'] },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            confidence: { type: Type.INTEGER },
            resources: { type: Type.STRING, description: "A brief summary of required resources (e.g., funding, personnel, equipment)." },
          },
          required: ['id', 'type', 'title', 'description', 'confidence', 'resources'],
        },
      },
    },
  });
  const rawHypotheses = JSON.parse(response.text);
  // The response from Gemini will not have the priority field. We add a default.
  return rawHypotheses.map((h: Omit<Hypothesis, 'priority'>) => ({
    ...h,
    priority: 'Medium' as const,
  }));
};

export const simulateAgentDebate = async (problem: string, hypotheses: Hypothesis[]): Promise<Debate> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: `${OMEGA_MASTER_PROMPT}\n\n**Current Task**: Execute STAGE 3: MULTI-AGENT DEBATE for the problem: "${problem}".\n\nHypotheses under consideration:\n${JSON.stringify(hypotheses)}\n\nSimulate a multi-agent debate to refine these hypotheses. Each agent (Dr. Elara, Kairo, Riva, Dr. Orion) must present their perspective, critique others, and build towards a consensus. Use the defined agent voices and signature moves. The debate should follow at least two rounds of interaction. Provide a final summary of the debate's conclusion.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "A brief summary of the debate's outcome and the consensus reached." },
          log: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                agent: { type: Type.STRING, enum: ['Scientist', 'Engineer', 'Impact Analyst', 'Simulation'] },
                dialogue: { type: Type.STRING, description: "The agent's dialogue for this turn of the debate." },
              },
              required: ['agent', 'dialogue'],
            },
          },
        },
        required: ['summary', 'log'],
      },
    },
  });
  return JSON.parse(response.text);
};

export const synthesizeSolution = async (problem: string, debate: Debate): Promise<Solution> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: `${OMEGA_MASTER_PROMPT}\n\n**Current Task**: Execute STAGE 4: CONSENSUS SOLUTION SYNTHESIS for the problem: "${problem}".\n\nThe agent debate has concluded with the following summary:\n${JSON.stringify(debate.summary)}\n\nSynthesize a comprehensive final solution. Adhere strictly to the specified output format, providing a title, summary, a 3-step blueprint, a detailed impact analysis, 3-5 quantifiable impact metrics, actionable next steps, key risks with mitigations, and suggestions for next experiments.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "A compelling title for the final solution." },
          summary: { type: Type.STRING, description: "A concise summary of the proposed solution." },
          blueprint: { type: Type.STRING, description: "The conceptual design or plan, formatted as a clear, multi-line string (e.g., using newlines for steps)." },
          impactAnalysis: { type: Type.STRING, description: "Analyze the potential positive and negative impacts in a brief paragraph." },
          impactMetrics: {
            type: Type.ARRAY,
            description: "A list of 3-5 key, quantifiable performance indicators.",
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                value: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                description: { type: Type.STRING },
              },
              required: ['label', 'value', 'unit', 'description'],
            },
          },
          nextSteps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of actionable next steps to implement the solution." },
          risksAndMitigations: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of key risks and how to mitigate them." },
          nextExperiments: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of crucial experiments to validate the solution." },
        },
        required: ['title', 'summary', 'blueprint', 'impactAnalysis', 'impactMetrics', 'nextSteps', 'risksAndMitigations', 'nextExperiments'],
      },
    },
  });
  return JSON.parse(response.text);
};

export const startChat = (
  isThinkingMode: boolean,
  isSearchGrounding: boolean,
  history: ChatMessage[]
): Chat => {
  let modelName = 'gemini-2.5-flash';
  const config: any = {};

  if (isThinkingMode) {
    modelName = 'gemini-2.5-pro';
    config.thinkingConfig = { thinkingBudget: 32768 };
  } else if (isSearchGrounding) {
    config.tools = [{ googleSearch: {} }];
  }

  config.systemInstruction = "You are OMEGA Assistant, a helpful AI integrated into the OMEGA problem-solving engine. Your creators are competing in the Google Cloud Run Hackathon. You have access to the knowledge of the entire OMEGA agent team (Dr. Elara, Kairo, Riva, Dr. Orion). Be concise, helpful, and provide accurate information to assist the user. Format responses using basic markdown.";

  const geminiHistory = history.map(msg => ({
    role: msg.role,
    parts: [{ text: msg.parts }]
  }));

  return ai.chats.create({
    model: modelName,
    config: config,
    history: geminiHistory,
  });
};