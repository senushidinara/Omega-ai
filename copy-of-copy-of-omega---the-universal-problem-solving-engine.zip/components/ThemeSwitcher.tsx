import React, { useState, useRef, useEffect } from 'react';
import { useTheme, THEMES, Theme } from '../contexts/ThemeContext';
import { PaletteIcon, SunIcon, MoonIcon } from './icons/ThemeIcons';

export const ThemeSwitcher: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleThemeChange = (newTheme: Theme) => {
    setTheme(newTheme);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-full bg-[--color-card-bg] border border-[--color-border-main] text-[--color-text-muted] hover:text-[--color-text-main] hover:border-[--color-accent] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[--color-bg] focus:ring-[--color-accent] transition-all duration-300"
        aria-label="Toggle theme selector"
      >
        <PaletteIcon className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-[--color-bg-secondary] border border-[--color-border-main] rounded-lg shadow-lg py-2 z-50 animate-fade-in" style={{animationDuration: '150ms'}}>
          {THEMES.map((themeOption) => (
            <button
              key={themeOption.name}
              onClick={() => handleThemeChange(themeOption.name)}
              className={`w-full text-left px-4 py-2 text-sm flex items-center justify-between ${
                theme === themeOption.name
                  ? 'bg-[--color-accent]/10 text-[--color-accent]'
                  : 'text-[--color-text-main] hover:bg-[--color-card-bg]'
              }`}
            >
              <span className="font-semibold">{themeOption.label}</span>
              {themeOption.isDark ? <MoonIcon className="w-4 h-4" /> : <SunIcon className="w-4 h-4" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};