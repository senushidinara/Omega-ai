import React, { useState } from 'react';

interface ProblemInputProps {
  onSolve: (problem: string) => void;
  isRunning: boolean;
}

export const ProblemInput: React.FC<ProblemInputProps> = ({ onSolve, isRunning }) => {
  const [problem, setProblem] = useState<string>('');
  const [placeholder, setPlaceholder] = useState<string>('e.g., "Design a scalable system to remove microplastics from oceans using renewable energy."');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (problem.trim() && !isRunning) {
      onSolve(problem.trim());
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="relative">
        <textarea
          value={problem}
          onChange={(e) => setProblem(e.target.value)}
          placeholder={placeholder}
          rows={3}
          className="w-full bg-[--color-card-bg] backdrop-blur-sm border border-[--color-border-accent] rounded-lg p-4 pr-36 text-[--color-text-main] focus:ring-2 focus:ring-[--color-accent] focus:border-[--color-accent] transition-all duration-300 resize-none text-lg placeholder:text-[--color-text-muted]/70"
          disabled={isRunning}
        />
        <button
          type="submit"
          disabled={isRunning || !problem.trim()}
          className="absolute top-1/2 right-4 -translate-y-1/2 px-6 py-3 bg-gradient-to-r from-[--color-accent] to-[--color-accent-secondary] text-white font-bold rounded-md hover:from-[--color-accent-hover] hover:to-[--color-accent] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-[--color-accent]/50 overflow-hidden"
        >
          <span className="relative z-10 flex items-center">
            {isRunning ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Thinking...
              </>
            ) : 'Solve'}
          </span>
          {!isRunning && <div className="absolute inset-0 animate-shimmer" />}
        </button>
      </form>
    </div>
  );
};