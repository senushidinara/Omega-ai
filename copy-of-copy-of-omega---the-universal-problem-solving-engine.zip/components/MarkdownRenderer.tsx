import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderContent = () => {
    if (!content) return null;

    // Split by code blocks and process the rest
    const parts = content.split(/(```[\s\S]*?```)/g);

    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const code = part.slice(3, -3).trim();
        return (
          <pre key={index} className="bg-[--color-bg] p-3 rounded-md my-2 text-sm font-roboto-mono border border-[--color-border-main] overflow-x-auto">
            <code>{code}</code>
          </pre>
        );
      }
      
      const lines = part.split('\n');
      const elements = [];
      let listItems: string[] = [];

      const flushList = () => {
        if (listItems.length > 0) {
          elements.push(
            <ul key={`list-${elements.length}`} className="list-disc list-inside space-y-1 my-2">
              {listItems.map((item, i) => (
                <li key={i} dangerouslySetInnerHTML={{ __html: processLine(item) }}></li>
              ))}
            </ul>
          );
          listItems = [];
        }
      };

      const processLine = (line: string) => {
        return line
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>'); // Bold
      }

      for (let i = 0; i < lines.length; i++) {
        let line = lines[i];

        if (line.startsWith('* ')) {
          listItems.push(line.substring(2));
        } else {
          flushList();
          if(line.trim() !== '') {
            elements.push(<p key={i} dangerouslySetInnerHTML={{ __html: processLine(line) }} />);
          }
        }
      }
      flushList();
      return <div key={index}>{elements}</div>;
    });
  };

  return <div className="prose prose-sm dark:prose-invert max-w-none prose-strong:text-[--color-text-main] prose-p:text-[--color-text-main] prose-li:text-[--color-text-main]">{renderContent()}</div>;
};