

import React from 'react';
import { AppState } from '../types';
import { STAGES, STAGE_TITLES } from '../constants';
import { StageCard } from './StageCard';
import { DeconstructionContent } from './contents/DeconstructionContent';
import { HypothesesContent } from './contents/HypothesesContent';
import { AgentDebateContent } from './contents/AgentDebateContent';
import { SolutionContent } from './contents/SolutionContent';

interface StageDisplayProps {
  appState: AppState;
}

export const StageDisplay: React.FC<StageDisplayProps> = ({ appState }) => {
  const { status, deconstruction, hypotheses, debate, solution, currentStage } = appState;

  const getStageStatus = (stage: typeof STAGES[number]) => {
    const stageIndex = STAGES.indexOf(stage);
    const currentStageIndex = currentStage ? STAGES.indexOf(currentStage) : -1;
    
    if (status === 'COMPLETED' || (currentStage && stageIndex < currentStageIndex)) {
        return 'completed';
    }
    if (currentStage === stage) {
        return 'running';
    }
    return 'pending';
  };
  
  const stageData = [
    { stage: 'DECONSTRUCTION', content: deconstruction && <DeconstructionContent data={deconstruction} /> },
    { stage: 'HYPOTHESIS', content: hypotheses.length > 0 && <HypothesesContent data={hypotheses} /> },
    { stage: 'DEBATE', content: debate && <AgentDebateContent data={debate} /> },
    { stage: 'SYNTHESIS', content: solution && <SolutionContent data={solution} /> },
  ];

  return (
    <div className="space-y-8">
      {stageData.map(({ stage, content }, index) => (
        <div key={stage} className="animate-fade-in" style={{ animationDelay: `${index * 150}ms`, opacity: 0 }}>
          <StageCard title={STAGE_TITLES[stage as keyof typeof STAGE_TITLES]} status={getStageStatus(stage as typeof STAGES[number])}>
            {content}
          </StageCard>
        </div>
      ))}
    </div>
  );
};