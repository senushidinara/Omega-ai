
import React from 'react';

export const OmegaIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l7.5-7.5 7.5 7.5m-15 3.375l7.5-7.5 7.5 7.5" />
    <path d="M12 21a9 9 0 100-18 9 9 0 000 18z" strokeOpacity="0.5" />
  </svg>
);
