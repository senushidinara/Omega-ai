import React, { useState, useEffect, useMemo, useRef } from 'react';
import type { Solution, ImpactMetric } from '../../types';
import { BlueprintIcon, ImpactAnalysisIcon, NextStepsIcon, RisksIcon, ExperimentsIcon, DragHandleIcon, SortAscIcon, SortDescIcon } from '../icons/SolutionIcons';

interface SolutionContentProps {
  data: Solution;
}

const Bar: React.FC<{ value: number; maxValue: number; isPercentage?: boolean }> = ({ value, maxValue, isPercentage }) => {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setWidth(maxValue > 0 ? (value / maxValue) * 100 : 0);
    }, 100);
    return () => clearTimeout(timer);
  }, [value, maxValue]);

  const barClasses = isPercentage
    ? 'bg-gradient-to-r from-indigo-500 to-purple-500'
    : 'bg-gradient-to-r from-[--color-accent-secondary] to-[--color-accent]';

  return (
    <div className="w-full bg-[--color-border-main] rounded-full h-4 relative overflow-hidden">
      <div
        className={`${barClasses} h-4 rounded-full transition-all duration-1000 ease-out`}
        style={{ width: `${width}%` }}
      />
    </div>
  );
};

const Section: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; className?: string }> = ({ title, icon, children, className = '' }) => (
    <div className={`bg-[--color-card-bg]/40 rounded-xl p-6 border border-[--color-border-main]/50 ${className}`}>
        <div className="flex items-center mb-4">
            <div className="text-[--color-accent] mr-3">{icon}</div>
            <h3 className="text-xl font-semibold text-[--color-text-main]">{title}</h3>
        </div>
        <div className="text-[--color-text-main] space-y-2 text-sm md:text-base">
          {children}
        </div>
    </div>
);


export const SolutionContent: React.FC<SolutionContentProps> = ({ data }) => {
  const [metrics, setMetrics] = useState<ImpactMetric[]>([]);
  const [filter, setFilter] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: 'value', direction: 'asc' | 'desc' } | null>(null);

  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);
  
  useEffect(() => {
    setMetrics(data.impactMetrics || []);
    setFilter('');
    setSortConfig(null);
  }, [data.impactMetrics]);

  const handleReorder = () => {
    if (dragItem.current === null || dragOverItem.current === null) return;
    const newMetrics = [...metrics];
    const draggedItemContent = newMetrics.splice(dragItem.current, 1)[0];
    newMetrics.splice(dragOverItem.current, 0, draggedItemContent);
    dragItem.current = null;
    dragOverItem.current = null;
    setMetrics(newMetrics);
  };
  
  const requestSort = (key: 'value') => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    } else if (sortConfig && sortConfig.key === key && sortConfig.direction === 'desc') {
      setSortConfig(null);
      return;
    }
    setSortConfig({ key, direction });
  };

  const processedMetrics = useMemo(() => {
    let processableMetrics = [...metrics];

    if (filter) {
      processableMetrics = processableMetrics.filter(m =>
        m.label.toLowerCase().includes(filter.toLowerCase())
      );
    }

    if (sortConfig !== null) {
      processableMetrics.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    return processableMetrics;
  }, [metrics, filter, sortConfig]);

  const maxNonPercentageValue = useMemo(() => Math.max(...(metrics.filter(m => m.unit !== '%').map(m => m.value)), 1), [metrics]);
  
  const isInteractive = !filter && !sortConfig;

  return (
    <div className="animate-fade-in space-y-8">
      <div className="text-center p-6 bg-gradient-to-b from-[--color-card-bg]/50 to-[--color-card-bg]/10 rounded-xl border border-[--color-border-main]">
        <h2 className="text-3xl lg:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[--color-accent] to-[--color-accent-secondary] mb-4">{data.title}</h2>
        <p className="max-w-3xl mx-auto text-[--color-text-muted]">{data.summary}</p>
      </div>

      <div className="grid lg:grid-cols-5 gap-8">
        <Section title="Conceptual Blueprint" icon={<BlueprintIcon className="w-6 h-6" />} className="lg:col-span-3">
          <div className="bg-[--color-bg-secondary]/50 p-4 rounded-md border border-[--color-border-main] mt-2">
            <pre className="text-xs md:text-sm font-roboto-mono text-[--color-text-main] whitespace-pre-wrap"><code>{data.blueprint}</code></pre>
          </div>
        </Section>
        
        <Section title="Impact Analysis" icon={<ImpactAnalysisIcon className="w-6 h-6" />} className="lg:col-span-2">
          <p className="mb-4 text-[--color-text-muted]">{data.impactAnalysis}</p>
          
          <div className="my-4 space-y-3">
             <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  placeholder="Filter metrics..."
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  className="w-full bg-[--color-bg-secondary] border border-[--color-border-main] rounded-md px-3 py-1.5 text-sm text-[--color-text-main] placeholder:text-[--color-text-muted]/70 focus:ring-1 focus:ring-[--color-accent] focus:border-[--color-accent] transition"
                />
                <button 
                  onClick={() => requestSort('value')}
                  className="flex items-center justify-center gap-2 px-3 py-1.5 bg-[--color-card-bg] hover:bg-[--color-border-main] border border-[--color-border-main] rounded-md text-sm text-[--color-text-muted] font-semibold transition whitespace-nowrap"
                >
                  Sort by Value 
                  {sortConfig?.direction === 'asc' ? <SortAscIcon className="w-4 h-4"/> : <SortDescIcon className="w-4 h-4" />}
                </button>
             </div>
             {!isInteractive && <p className="text-xs text-amber-600 dark:text-amber-400/80 text-center">Clear filters and sorting to reorder metrics.</p>}
          </div>

          <div className="space-y-5 mt-4 font-roboto-mono">
            {processedMetrics.map((metric) => {
              const maxValue = metric.unit === '%' ? 100 : maxNonPercentageValue;
              const originalIndex = metrics.findIndex(m => m.label === metric.label);

              return (
                <div
                  key={metric.label}
                  className={`group flex items-start gap-2 ${isInteractive ? 'cursor-grab' : 'cursor-default'}`}
                  draggable={isInteractive}
                  onDragStart={() => (dragItem.current = originalIndex)}
                  onDragEnter={() => (dragOverItem.current = originalIndex)}
                  onDragEnd={handleReorder}
                  onDragOver={(e) => e.preventDefault()}
                >
                  {isInteractive && <DragHandleIcon className="w-5 h-5 text-[--color-text-muted] mt-0.5 flex-shrink-0" />}
                  <div className="w-full">
                    <div className="flex justify-between items-baseline mb-1 text-sm">
                      <span className="text-[--color-text-main] font-semibold">{metric.label}</span>
                      <span className="text-[--color-accent] font-bold flex items-baseline">
                        <span>{metric.value.toLocaleString()}</span>
                        {metric.unit === '%' 
                          ? <span className="text-sm font-normal text-[--color-accent]/80 ml-0.5">%</span> 
                          : <span className="text-xs font-normal text-[--color-text-muted] ml-1">{metric.unit}</span>
                        }
                      </span>
                    </div>
                    <Bar value={metric.value} maxValue={maxValue} isPercentage={metric.unit === '%'} />
                    <p className="text-xs text-[--color-text-muted] mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out">
                      {metric.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Section title="Risks & Mitigations" icon={<RisksIcon className="w-6 h-6" />}>
          <ul className="list-disc list-inside space-y-2 text-[--color-text-muted]">
            {data.risksAndMitigations?.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </Section>
        <Section title="Next Experiments" icon={<ExperimentsIcon className="w-6 h-6" />}>
           <ul className="list-disc list-inside space-y-2 text-[--color-text-muted]">
            {data.nextExperiments?.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </Section>
      </div>

      <Section title="Next Steps" icon={<NextStepsIcon className="w-6 h-6" />}>
        <ul className="space-y-3 mt-2 text-[--color-text-main]">
          {data.nextSteps.map((step, index) => (
            <li key={index} className="flex items-start">
              <div className="flex-shrink-0 w-6 h-6 bg-[--color-accent]/10 text-[--color-accent] rounded-full flex items-center justify-center mr-4 mt-0.5 font-bold text-xs">
                {index + 1}
              </div>
              <span>{step}</span>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
};