import React, { useState, useEffect, useMemo } from 'react';
import type { Hypothesis } from '../../types';

interface HypothesisCardProps {
  hypothesis: Hypothesis;
  onPriorityChange: (id: number, priority: 'High' | 'Medium' | 'Low') => void;
}

const HypothesisCard: React.FC<HypothesisCardProps> = ({ hypothesis, onPriorityChange }) => {
  const typeColor = {
    'Scientific': 'bg-sky-500/10 dark:bg-sky-500/20 text-sky-700 dark:text-sky-300 border-sky-500/30',
    'Engineering': 'bg-amber-500/10 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/30',
    'Policy': 'bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 border-indigo-500/30',
    'Social': 'bg-rose-500/10 dark:bg-rose-500/20 text-rose-700 dark:text-rose-300 border-rose-500/30',
  }[hypothesis.type];

  const priorityStyles = {
    High: {
      borderColor: 'border-red-500/60',
      buttonBg: 'bg-red-500/10 text-red-700 dark:text-red-300',
      activeButtonBg: 'bg-red-500 text-white',
    },
    Medium: {
      borderColor: 'border-sky-500/60',
      buttonBg: 'bg-sky-500/10 text-sky-700 dark:text-sky-300',
      activeButtonBg: 'bg-sky-500 text-white',
    },
    Low: {
      borderColor: 'border-[--color-border-main]',
      buttonBg: 'bg-[--color-border-main] text-[--color-text-muted]',
      activeButtonBg: 'bg-gray-500 text-white',
    },
  };

  const currentPriorityStyle = priorityStyles[hypothesis.priority];

  return (
    <div className={`bg-[--color-bg-secondary]/60 p-4 rounded-lg border h-full flex flex-col transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:shadow-[--color-accent]/10 ${currentPriorityStyle.borderColor}`}>
      <div className="flex justify-between items-start mb-3">
        <span className={`px-2 py-1 text-xs font-bold rounded ${typeColor}`}>{hypothesis.type}</span>
        <div className="text-right w-1/3">
          <div className="font-bold text-lg text-[--color-accent]">{hypothesis.confidence}%</div>
          <div className="text-xs text-[--color-text-muted] mb-1">Confidence</div>
          <div className="w-full bg-[--color-border-main] rounded-full h-1.5">
            <div
              className="bg-gradient-to-r from-[--color-accent-secondary] to-[--color-accent] h-1.5 rounded-full"
              style={{ width: `${hypothesis.confidence}%` }}
            />
          </div>
        </div>
      </div>
      <h4 className="font-bold text-lg text-[--color-text-main] mb-2">{hypothesis.title}</h4>
      <p className="text-[--color-text-muted] text-sm flex-grow mb-4">{hypothesis.description}</p>
      <div className="mb-4">
        <h5 className="text-xs text-[--color-text-muted] mb-1 font-semibold">Resources</h5>
        <p className="text-sm text-[--color-text-main] font-roboto-mono">{hypothesis.resources}</p>
      </div>
      <div className="mt-auto pt-3 border-t border-[--color-border-main]/50">
        <h5 className="text-xs text-[--color-text-muted] mb-2 font-semibold">Set Priority</h5>
        <div className="flex items-center justify-around">
          {(['High', 'Medium', 'Low'] as const).map((p) => (
            <button
              key={p}
              onClick={() => onPriorityChange(hypothesis.id, p)}
              className={`px-3 py-1 w-20 text-xs font-bold rounded-full transition-all duration-200 transform hover:scale-105 ${
                hypothesis.priority === p 
                  ? priorityStyles[p].activeButtonBg 
                  : `${priorityStyles[p].buttonBg} hover:opacity-80`
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

interface HypothesesContentProps {
  data: Hypothesis[];
}

export const HypothesesContent: React.FC<HypothesesContentProps> = ({ data }) => {
  const [hypotheses, setHypotheses] = useState<Hypothesis[]>([]);
  const [sortBy, setSortBy] = useState<'default' | 'priority' | 'confidence'>('default');

  useEffect(() => {
    setHypotheses(data);
    setSortBy('default');
  }, [data]);

  const handlePriorityChange = (id: number, priority: 'High' | 'Medium' | 'Low') => {
    setHypotheses(prev => prev.map(h => h.id === id ? { ...h, priority } : h));
  };
  
  const sortedHypotheses = useMemo(() => {
    const sorted = [...hypotheses];
    if (sortBy === 'priority') {
      const priorityOrder = { High: 0, Medium: 1, Low: 2 };
      sorted.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
    } else if (sortBy === 'confidence') {
      sorted.sort((a, b) => b.confidence - a.confidence);
    }
    return sorted;
  }, [hypotheses, sortBy]);

  const SortButton: React.FC<{ label: string; value: typeof sortBy; }> = ({ label, value }) => (
    <button 
      onClick={() => setSortBy(value)}
      className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 ${
        sortBy === value 
        ? 'bg-[--color-accent] text-white shadow-md shadow-[--color-accent]/20' 
        : 'bg-[--color-card-bg] text-[--color-text-muted] hover:bg-[--color-border-main]'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div>
      <div className="flex justify-end items-center gap-2 mb-4">
        <span className="text-sm text-[--color-text-muted]">Sort by:</span>
        <SortButton label="Default" value="default" />
        <SortButton label="Priority" value="priority" />
        <SortButton label="Confidence" value="confidence" />
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        {sortedHypotheses.map((hyp) => (
          <HypothesisCard key={hyp.id} hypothesis={hyp} onPriorityChange={handlePriorityChange} />
        ))}
      </div>
    </div>
  );
};