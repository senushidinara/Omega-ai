import React, { useEffect, useState, useRef } from 'react';
import type { Debate, DebateEntry } from '../../types';
import { ScientistIcon, EngineerIcon, ImpactAnalystIcon, SimulationIcon } from '../icons/AgentIcons';

interface AgentDebateContentProps {
  data: Debate;
}

const agentDetails = {
  Scientist: { 
    name: "Dr. Elara",
    role: "Scientist",
    icon: ScientistIcon, 
    color: 'text-sky-600 dark:text-sky-400',
    bgColor: 'bg-sky-500',
    description: 'Analyzes scientific validity, grounding hypotheses in peer-reviewed research and first principles to ensure they are novel and feasible.'
  },
  Engineer: { 
    name: "Kairo",
    role: "Engineer",
    icon: EngineerIcon, 
    color: 'text-amber-600 dark:text-amber-400',
    bgColor: 'bg-amber-500',
    description: 'Evaluates practical implementation, focusing on manufacturing scalability, material costs, and real-world engineering viability.'
  },
  'Impact Analyst': { 
    name: "Riva",
    role: "Impact Analyst",
    icon: ImpactAnalystIcon, 
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-500',
    description: 'Quantifies the potential for real-world change, modeling CO₂ reduction, cost-benefit, and global market adoption.'
  },
  Simulation: {
    name: "Dr. Orion",
    role: "Simulation",
    icon: SimulationIcon,
    color: 'text-indigo-600 dark:text-indigo-400',
    bgColor: 'bg-indigo-500',
    description: 'Provides quantitative validation by running predictive models and simulations to calculate efficiency and success probability.'
  }
};

const Typewriter: React.FC<{ text: string }> = ({ text }) => {
    const [displayedText, setDisplayedText] = useState('');
    useEffect(() => {
        let i = 0;
        setDisplayedText(''); // Reset on text change
        const intervalId = setInterval(() => {
            if (i < text.length) {
                setDisplayedText(prev => prev + text.charAt(i));
                i++;
            } else {
                clearInterval(intervalId);
            }
        }, 10);
        return () => clearInterval(intervalId);
    }, [text]);

    return <>{displayedText}</>;
}

export const AgentDebateContent: React.FC<AgentDebateContentProps> = ({ data }) => {
  const [visibleLog, setVisibleLog] = useState<DebateEntry[]>([]);
  const debateLogEndRef = useRef<HTMLDivElement>(null);
  const [isAgentsVisible, setIsAgentsVisible] = useState(false);
  
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [timelineHeight, setTimelineHeight] = useState(0);

  useEffect(() => {
    setVisibleLog([]);
    setTimelineHeight(0);
    itemRefs.current = [];

    if (data?.log?.length > 0) {
      const timeouts = data.log.map((_, index) => {
        return window.setTimeout(() => {
          setVisibleLog(prev => [...prev, data.log[index]]);
        }, index * 2500 + 500);
      });

      return () => {
        timeouts.forEach(clearTimeout);
      };
    }
  }, [data]);

  useEffect(() => {
    debateLogEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });

    const lastVisibleIndex = visibleLog.length - 1;
    if (lastVisibleIndex < 0) {
        setTimelineHeight(0);
        return;
    }
    const lastItemElement = itemRefs.current[lastVisibleIndex];
    if (lastItemElement) {
        const newHeight = lastItemElement.offsetTop + (lastItemElement.offsetHeight / 2);
        setTimelineHeight(newHeight);
    }

  }, [visibleLog]);

  return (
    <div>
      <div className="mb-6 p-4 bg-[--color-card-bg]/70 border border-[--color-border-main] rounded-lg">
        <h4 className="font-semibold text-[--color-accent] mb-1">Debate Conclusion</h4>
        <p className="text-[--color-text-muted] italic">{data.summary}</p>
      </div>
      
      <details className="mb-8" onToggle={(e) => setIsAgentsVisible((e.target as HTMLDetailsElement).open)}>
        <summary className="list-none text-center text-[--color-accent] font-semibold text-xl hover:text-[--color-accent-hover] transition-colors cursor-pointer">
          <h3>{isAgentsVisible ? 'Hide Agent Profiles' : 'Meet the Agents'}</h3>
        </summary>
        <div className="mt-6 p-6 bg-[--color-card-bg]/30 border border-[--color-border-main] rounded-xl backdrop-blur-sm animate-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {(Object.values(agentDetails)).map((details) => {
              const AgentIcon = details.icon;
              return (
                <div key={details.name} className={`relative bg-[--color-bg-secondary]/50 p-6 rounded-lg border border-[--color-border-main] text-center flex flex-col items-center h-full transition-all duration-300 hover:border-[--color-accent]/70 hover:bg-[--color-bg-secondary] hover:scale-105 overflow-hidden`}>
                  <div className={`absolute top-0 left-0 right-0 h-1.5 ${details.bgColor}`}></div>
                  <div className={`flex-shrink-0 p-3 bg-[--color-card-bg] rounded-full border-2 border-[--color-border-main] ${details.color}`}>
                    <AgentIcon className="w-8 h-8" />
                  </div>
                  <h5 className={`font-bold text-lg mt-4 mb-1 ${details.color}`}>{details.name}</h5>
                  <p className="text-xs text-[--color-text-muted] mb-2 uppercase tracking-wider">{details.role}</p>
                  <p className="text-sm text-[--color-text-main] flex-grow">{details.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </details>

      <div className="relative font-roboto-mono text-sm mt-12">
        <div className="hidden md:block absolute left-1/2 top-0 -translate-x-1/2 h-full w-0.5 bg-[--color-border-main]/50 rounded" />
        <div 
          className="hidden md:block absolute left-1/2 top-0 -translate-x-1/2 w-0.5 bg-[--color-accent] rounded transition-all duration-500 ease-out"
          style={{ height: `${timelineHeight}px` }}
        />
        <div className="space-y-12">
          {visibleLog.map((entry, index) => {
            const isLeft = index % 2 === 0;
            const agentDetail = agentDetails[entry.agent];
            const isLastVisible = index === visibleLog.length - 1;
            if (!agentDetail) return null;
            const { icon: Icon, color, name } = agentDetail;
            const animationClass = isLeft ? 'animate-slide-in-left' : 'animate-slide-in-right';

            return (
              <div ref={el => { itemRefs.current[index] = el; }} key={index} className={`md:flex items-start ${isLeft ? '' : 'md:flex-row-reverse'} w-full`}>
                <div className="w-full md:w-1/2 flex justify-center">
                  <div className={`md:w-11/12 p-4 bg-[--color-bg-secondary] border border-[--color-border-main] rounded-lg relative ${animationClass}`}>
                    <div className={`hidden md:block absolute top-6 -translate-y-1/2 w-3 h-3 bg-[--color-bg-secondary] border-[--color-border-main] transform rotate-45 ${isLeft ? 'right-[-6.5px] border-t border-r' : 'left-[-6.5px] border-b border-l'}`} />
                    <div className="flex items-center space-x-3 mb-2 md:hidden">
                      <div className={`p-1.5 bg-[--color-card-bg] rounded-full border border-[--color-border-main] ${color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <h5 className={`font-bold ${color}`}>{name}</h5>
                    </div>
                    <h5 className={`hidden md:block font-bold ${color} ${isLeft ? '' : 'text-right'}`}>{name}</h5>
                    <p className={`text-[--color-text-main] ${isLeft ? '' : 'md:text-right'}`}>
                      <Typewriter text={entry.dialogue} />
                    </p>
                  </div>
                </div>
                <div className="hidden md:flex w-1/2 justify-center relative">
                  <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-[--color-border-main] rounded-full z-0" />
                  <div className={`absolute top-1/2 -translate-y-1/2 p-2 bg-[--color-card-bg] rounded-full border-2 border-[--color-border-main] ${color} z-10 ${isLastVisible ? 'animate-pulse-glow' : ''}`}>
                    <Icon className="w-8 h-8" />
                  </div>
                </div>
              </div>
            );
          })}
          {data.log && visibleLog.length > 0 && visibleLog.length < data.log.length && (
            <div className="flex items-center justify-center pt-6 animate-fade-in">
              <div className="flex items-center space-x-1.5 p-2 bg-[--color-bg-secondary]/80 rounded-full border border-[--color-border-main]">
                <div className="w-2 h-2 bg-[--color-text-muted] rounded-full animate-typing-dot" />
                <div className="w-2 h-2 bg-[--color-text-muted] rounded-full animate-typing-dot" style={{ animationDelay: '0.2s' }} />
                <div className="w-2 h-2 bg-[--color-text-muted] rounded-full animate-typing-dot" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
          <div ref={debateLogEndRef} />
        </div>
      </div>
    </div>
  );
};