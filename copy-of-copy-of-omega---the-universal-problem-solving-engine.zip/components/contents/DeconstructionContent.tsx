import React from 'react';
import type { ProblemDeconstruction } from '../../types';

interface DeconstructionContentProps {
  data: ProblemDeconstruction;
}

const InfoBlock: React.FC<{ title: string; items: string[] }> = ({ title, items }) => (
  <div>
    <h3 className="text-lg font-semibold text-[--color-accent] mb-2">{title}</h3>
    <ul className="list-disc list-inside space-y-1 text-[--color-text-main] font-roboto-mono text-sm">
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  </div>
);

export const DeconstructionContent: React.FC<DeconstructionContentProps> = ({ data }) => {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <InfoBlock title="Key Variables" items={data.keyVariables} />
      <InfoBlock title="Constraints" items={data.constraints} />
      <InfoBlock title="Desired Outcomes" items={data.desiredOutcomes} />
      <InfoBlock title="Knowledge Fields" items={data.knowledgeFields} />
    </div>
  );
};