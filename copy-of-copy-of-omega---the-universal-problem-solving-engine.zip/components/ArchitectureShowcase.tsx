import React from 'react';
import { DeconstructIcon, HypothesisIcon, DebateIcon, SynthesisIcon } from './icons/ArchitectureIcons';

const FlowStep: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
  <div className="flex flex-col items-center text-center p-2 max-w-[200px] flex-1">
    <div className="w-16 h-16 bg-[--color-bg-secondary]/60 border-2 border-[--color-accent]/30 rounded-full flex items-center justify-center text-[--color-accent] mb-4 transition-all duration-300 hover:bg-[--color-accent]/10 hover:border-[--color-accent]/80 hover:scale-110">
      {icon}
    </div>
    <h3 className="font-semibold text-[--color-text-main] text-lg mb-1">{title}</h3>
    <p className="text-sm text-[--color-text-muted]">{description}</p>
  </div>
);

const Arrow: React.FC<{ className?: string }> = ({ className = '' }) => (
    <div className={`text-[--color-text-muted]/50 self-center hidden md:block ${className}`}>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 8l4 4m0 0l-4 4m4-4H3" />
        </svg>
    </div>
);

const DownArrow: React.FC<{ className?: string }> = ({ className = '' }) => (
    <div className={`text-[--color-text-muted]/50 self-center md:hidden ${className}`}>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 4v16m0 0l-4-4m4 4l4-4" />
        </svg>
    </div>
);


export const ArchitectureShowcase: React.FC = () => {
    return (
        <div className="max-w-5xl mx-auto my-12 text-center animate-fade-in" style={{ animationDelay: '300ms' }}>
            <div className="bg-[--color-card-bg]/50 border border-[--color-border-main]/50 rounded-xl p-8 backdrop-blur-sm">
                <h2 className="text-2xl md:text-3xl font-bold text-[--color-text-main] mb-3">How OMEGA Works</h2>
                <p className="text-[--color-text-muted] mb-10 max-w-3xl mx-auto">
                    OMEGA utilizes a four-stage cognitive architecture, powered by Google Gemini, to systematically solve complex problems.
                </p>
                
                <div className="flex flex-col md:flex-row items-stretch justify-center gap-4">
                    <FlowStep 
                        title="Deconstruction" 
                        description="Analyzes the problem, identifying key variables, constraints, and desired outcomes."
                        icon={<DeconstructIcon className="w-8 h-8" />}
                    />
                    <Arrow />
                    <DownArrow />
                    <FlowStep 
                        title="Hypothesis" 
                        description="Generates diverse, testable hypotheses from multiple agent perspectives."
                        icon={<HypothesisIcon className="w-8 h-8" />}
                    />
                    <Arrow />
                    <DownArrow />
                    <FlowStep 
                        title="Debate" 
                        description="Specialized AI agents critique, refine, and build upon hypotheses in a simulated debate."
                        icon={<DebateIcon className="w-8 h-8" />}
                    />
                    <Arrow />
                    <DownArrow />
                    <FlowStep 
                        title="Synthesis" 
                        description="Consolidates the debate into a final, actionable solution with a blueprint and impact analysis."
                        icon={<SynthesisIcon className="w-8 h-8" />}
                    />
                </div>
            </div>
        </div>
    );
};