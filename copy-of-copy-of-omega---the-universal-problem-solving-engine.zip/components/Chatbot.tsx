import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Chat } from '@google/genai';
import { startChat } from '../services/geminiService';
import type { ChatMessage } from '../types';
import { ChatIcon, CloseIcon, SendIcon, BrainIcon, SearchIcon, TrashIcon } from './icons/ChatIcons';
import { MarkdownRenderer } from './MarkdownRenderer';
import { OmegaIcon } from './icons/OmegaIcon';

const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-1.5 p-2">
        <div className="w-2 h-2 bg-[--color-accent] rounded-full animate-typing-dot" />
        <div className="w-2 h-2 bg-[--color-accent] rounded-full animate-typing-dot" style={{ animationDelay: '0.2s' }} />
        <div className="w-2 h-2 bg-[--color-accent] rounded-full animate-typing-dot" style={{ animationDelay: '0.4s' }} />
    </div>
);

export const Chatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isThinkingMode, setIsThinkingMode] = useState(false);
    const [isSearchGrounding, setIsSearchGrounding] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatSessionRef = useRef<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [animationClass, setAnimationClass] = useState('');

    const getStorageKey = useCallback(() => {
        if (isThinkingMode) return 'omegaChatHistory_thinking';
        if (isSearchGrounding) return 'omegaChatHistory_grounding';
        return 'omegaChatHistory_default';
    }, [isThinkingMode, isSearchGrounding]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    // Load messages from localStorage when component opens or mode changes
    useEffect(() => {
        if (isOpen) {
            chatSessionRef.current = null; // Always reset the backend session
            const storageKey = getStorageKey();
            try {
                const savedMessages = localStorage.getItem(storageKey);
                setMessages(savedMessages ? JSON.parse(savedMessages) : []);
            } catch (error) {
                console.error("Failed to load chat history:", error);
                setMessages([]);
            }
        }
    }, [isOpen, isThinkingMode, isSearchGrounding, getStorageKey]);

    // Save messages to localStorage whenever they change
    useEffect(() => {
        if (!isOpen) return;
        const storageKey = getStorageKey();
        try {
            localStorage.setItem(storageKey, JSON.stringify(messages));
        } catch (error) {
            console.error("Failed to save chat history:", error);
        }
    }, [messages, getStorageKey, isOpen]);


    const handleToggle = () => {
        if (isOpen) {
            setAnimationClass('animate-slide-out');
            setTimeout(() => setIsOpen(false), 300);
        } else {
            setIsOpen(true);
            setAnimationClass('animate-slide-in');
        }
    };

    const handleClearChat = () => {
        if (isLoading) return;
        chatSessionRef.current = null;
        setMessages([]); 
    };
    
    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const newUserMessage: ChatMessage = { role: 'user', parts: input };
        setMessages(prev => [...prev, newUserMessage]);
        setInput('');
        setIsLoading(true);

        try {
            if (!chatSessionRef.current) {
                chatSessionRef.current = startChat(isThinkingMode, isSearchGrounding, messages);
            }
            
            const stream = await chatSessionRef.current.sendMessageStream({ message: newUserMessage.parts });
            
            let fullResponse = '';
            let modelMessage: ChatMessage = { role: 'model', parts: '' };
            setMessages(prev => [...prev, modelMessage]);

            for await (const chunk of stream) {
                fullResponse += chunk.text;
                const sources = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
                
                setMessages(prev => prev.map((msg, index) => 
                    index === prev.length - 1 
                    ? { ...msg, parts: fullResponse, sources: sources ?? msg.sources } 
                    : msg
                ));
            }
        } catch (error) {
            console.error('Chatbot error:', error);
            const errorMessage: ChatMessage = { role: 'model', parts: 'Sorry, I encountered an error. Please try again.' };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const ChatToggle: React.FC<{isActive: boolean, onToggle: () => void, icon: React.ReactNode, label: string}> = ({isActive, onToggle, icon, label}) => (
        <button
            onClick={onToggle}
            className={`flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold rounded-full border transition-all duration-200 ${
                isActive 
                ? 'bg-[--color-accent]/20 border-[--color-accent] text-[--color-accent]' 
                : 'bg-[--color-card-bg] border-[--color-border-main] text-[--color-text-muted] hover:bg-[--color-border-main]'
            }`}
            title={label}
        >
            {icon}
            <span>{label}</span>
        </button>
    );

    return (
        <>
            <button
                onClick={handleToggle}
                className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-[--color-accent] to-[--color-accent-secondary] rounded-full text-white shadow-2xl shadow-[--color-accent]/30 flex items-center justify-center transform hover:scale-110 transition-transform duration-200 ease-in-out focus:outline-none focus:ring-4 focus:ring-[--color-accent]/50 z-50"
                aria-label="Toggle Chat"
            >
                {isOpen ? <CloseIcon className="w-8 h-8" /> : <ChatIcon className="w-8 h-8" />}
            </button>

            {isOpen && (
                <div className={`fixed bottom-24 right-6 w-[90vw] max-w-md h-[70vh] max-h-[600px] flex flex-col bg-[--color-bg-secondary]/80 backdrop-blur-xl border border-[--color-border-accent] rounded-2xl shadow-2xl shadow-[--color-accent]/20 z-40 ${animationClass} origin-bottom-right`}>
                    <header className="flex items-center justify-between p-4 border-b border-[--color-border-main] flex-shrink-0">
                        <div className="flex items-center space-x-3">
                            <OmegaIcon className="w-8 h-8 text-[--color-accent]" />
                            <h2 className="text-lg font-bold text-[--color-text-main]">OMEGA Assistant</h2>
                        </div>
                        <button onClick={handleToggle} className="text-[--color-text-muted] hover:text-[--color-text-main] transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </header>

                    <div className="flex-grow p-4 overflow-y-auto chatbot-scrollbar">
                        <div className="space-y-4">
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[85%] px-4 py-2.5 rounded-2xl ${msg.role === 'user' ? 'bg-[--color-accent-secondary] text-white rounded-br-lg' : 'bg-[--color-card-bg] text-[--color-text-main] rounded-bl-lg'}`}>
                                        <MarkdownRenderer content={msg.parts} />
                                        {msg.sources && msg.sources.length > 0 && (
                                            <div className="mt-3 pt-2 border-t border-[--color-border-main]">
                                                <h4 className="text-xs font-bold text-[--color-text-muted] mb-1.5">Sources:</h4>
                                                <div className="flex flex-wrap gap-2">
                                                    {msg.sources.map((source, i) => source.web && (
                                                        <a href={source.web.uri} target="_blank" rel="noopener noreferrer" key={i} className="text-xs bg-[--color-card-bg] hover:bg-[--color-border-main] text-[--color-accent] px-2 py-1 rounded-md transition-colors truncate">
                                                            {source.web.title}
                                                        </a>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                             {isLoading && (
                                <div className="flex justify-start">
                                    <div className="px-4 py-2.5 rounded-2xl bg-[--color-card-bg] rounded-bl-lg">
                                       <TypingIndicator />
                                    </div>
                                </div>
                            )}
                        </div>
                        <div ref={messagesEndRef} />
                    </div>

                    <footer className="p-4 border-t border-[--color-border-main] flex-shrink-0">
                        <div className="flex items-center justify-center space-x-2 mb-3">
                           <ChatToggle 
                             isActive={isThinkingMode}
                             onToggle={() => { setIsThinkingMode(p => !p); setIsSearchGrounding(false); }}
                             icon={<BrainIcon className="w-4 h-4" />}
                             label="Thinking Mode"
                           />
                           <ChatToggle 
                             isActive={isSearchGrounding}
                             onToggle={() => { setIsSearchGrounding(p => !p); setIsThinkingMode(false); }}
                             icon={<SearchIcon className="w-4 h-4" />}
                             label="Grounding"
                           />
                           <button
                                onClick={handleClearChat}
                                disabled={isLoading || messages.length === 0}
                                className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold rounded-full border border-[--color-border-main] text-[--color-text-muted] bg-[--color-card-bg] hover:bg-[--color-border-main] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                                title="Clear Chat"
                            >
                                <TrashIcon className="w-4 h-4" />
                                <span>Clear</span>
                            </button>
                        </div>
                        <form onSubmit={handleSendMessage} className="relative">
                            <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Ask OMEGA anything..."
                                className="w-full bg-[--color-card-bg] border border-[--color-border-main] rounded-full py-3 pl-5 pr-14 text-[--color-text-main] focus:ring-2 focus:ring-[--color-accent] focus:border-[--color-accent] transition-all duration-300 placeholder:text-[--color-text-muted]/70"
                                disabled={isLoading}
                            />
                            <button
                                type="submit"
                                disabled={isLoading || !input.trim()}
                                className="absolute top-1/2 right-2 -translate-y-1/2 w-10 h-10 bg-gradient-to-r from-[--color-accent] to-[--color-accent-secondary] text-white font-bold rounded-full hover:from-[--color-accent-hover] hover:to-[--color-accent] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-110 flex items-center justify-center"
                                aria-label="Send message"
                            >
                                <SendIcon className="w-5 h-5" />
                            </button>
                        </form>
                    </footer>
                </div>
            )}
        </>
    );
};