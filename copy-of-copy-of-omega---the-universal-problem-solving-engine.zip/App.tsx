import React, { useState, useCallback } from 'react';
import { ProblemInput } from './components/ProblemInput';
import { StageDisplay } from './components/StageDisplay';
import { OmegaIcon } from './components/icons/OmegaIcon';
import { deconstructProblem, generateHypotheses, simulateAgentDebate, synthesizeSolution } from './services/geminiService';
import type { AppState } from './types';
import { Chatbot } from './components/Chatbot';
import { ArchitectureShowcase } from './components/ArchitectureShowcase';
import { ThemeSwitcher } from './components/ThemeSwitcher';

const initialState: AppState = {
  problem: '',
  status: 'IDLE',
  deconstruction: null,
  hypotheses: [],
  debate: null,
  solution: null,
  error: null,
  currentStage: null,
};

function App() {
  const [state, setState] = useState<AppState>(initialState);

  const resetState = useCallback(() => {
    setState(initialState);
  }, []);

  const handleSolve = useCallback(async (problem: string) => {
    // Reset state but keep the new problem
    setState({
      ...initialState,
      problem,
      status: 'RUNNING',
      currentStage: 'DECONSTRUCTION'
    });

    try {
      // Stage 1: Deconstruction
      const deconstruction = await deconstructProblem(problem);
      setState(prevState => ({ ...prevState, deconstruction, currentStage: 'HYPOTHESIS' }));
      
      // Stage 2: Hypothesis Generation
      const hypotheses = await generateHypotheses(problem, deconstruction);
      setState(prevState => ({ ...prevState, hypotheses, currentStage: 'DEBATE' }));

      // Stage 3: Agent Debate
      const debate = await simulateAgentDebate(problem, hypotheses);
      setState(prevState => ({ ...prevState, debate, currentStage: 'SYNTHESIS' }));

      // Stage 4: Solution Synthesis
      const solution = await synthesizeSolution(problem, debate);
      setState(prevState => ({ ...prevState, solution, status: 'COMPLETED', currentStage: null }));

    } catch (error) {
      console.error("OMEGA Engine failed:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setState(prevState => ({ ...prevState, error: `OMEGA Engine failed: ${errorMessage}`, status: 'ERROR', currentStage: null }));
    }
  }, []);

  return (
    <div className="min-h-screen text-[--color-text-main]">
      <header className="absolute top-0 right-0 p-4 z-10">
        <ThemeSwitcher />
      </header>
      <main className="container mx-auto px-4 py-8 md:py-16">
        <div className="text-center mb-12 animate-fade-in">
          <div className="inline-block p-4 bg-[--color-card-bg] rounded-full border border-[--color-border-main] mb-4 animate-logo-glow">
            <OmegaIcon className="w-12 h-12 text-[--color-accent]" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-[--color-gradient-from] to-[--color-gradient-to]">
            OMEGA
          </h1>
          <p className="max-w-2xl mx-auto text-[--color-text-muted]">
            An AI civilization that generates hypotheses, debates, and builds solutions – for any problem in the world.
          </p>
        </div>

        <div className="mb-12 animate-fade-in" style={{ animationDelay: '150ms' }}>
          <ProblemInput onSolve={handleSolve} isRunning={state.status === 'RUNNING'} />
        </div>

        {state.status === 'IDLE' && <ArchitectureShowcase />}
        
        {state.status !== 'IDLE' && (
          <div className="max-w-5xl mx-auto">
            {state.problem && <h2 className="text-center text-2xl font-semibold mb-8 text-[--color-text-muted]">Solving for: <span className="text-[--color-accent]">"{state.problem}"</span></h2>}
            <StageDisplay appState={state} />
          </div>
        )}

        {state.status === 'ERROR' && state.error && (
          <div className="max-w-3xl mx-auto mt-8 p-4 bg-red-100 dark:bg-red-900/50 border border-red-300 dark:border-red-500/50 rounded-lg text-center animate-fade-in">
            <h3 className="font-bold text-red-700 dark:text-red-300 mb-2">An Error Occurred</h3>
            <p className="text-red-600/80 dark:text-red-300/80 font-roboto-mono text-sm">{state.error}</p>
            <button
              onClick={resetState}
              className="mt-4 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-md transition-colors"
            >
              Try Again
            </button>
          </div>
        )}
      </main>
      <Chatbot />
    </div>
  );
}

export default App;