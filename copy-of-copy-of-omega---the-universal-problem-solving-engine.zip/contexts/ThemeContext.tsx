import React, { createContext, useContext, useState, useEffect } from 'react';

export type Theme = 'slate' | 'twilight' | 'daybreak' | 'dusk' | 'mint';

export const THEMES: { name: Theme; isDark: boolean, label: string }[] = [
  { name: 'slate', isDark: false, label: 'Slate' },
  { name: 'daybreak', isDark: false, label: 'Daybreak' },
  { name: 'mint', isDark: false, label: 'Mint' },
  { name: 'twilight', isDark: true, label: 'Twilight' },
  { name: 'dusk', isDark: true, label: 'Dusk' },
];

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedTheme = window.localStorage.getItem('theme') as Theme;
      if (storedTheme && THEMES.some(t => t.name === storedTheme)) {
        return storedTheme;
      }
      // Deprecated check for old 'dark'/'light' values
      const legacyTheme = window.localStorage.getItem('theme');
      if (legacyTheme === 'dark') return 'twilight';
      if (legacyTheme === 'light') return 'slate';
      
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'twilight';
      }
    }
    return 'twilight'; // Default theme
  });

  useEffect(() => {
    const root = window.document.documentElement;
    const selectedTheme = THEMES.find(t => t.name === theme);

    if (selectedTheme?.isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    
    root.dataset.theme = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};