export interface ProblemDeconstruction {
  keyVariables: string[];
  constraints: string[];
  desiredOutcomes: string[];
  knowledgeFields: string[];
}

export interface Hypothesis {
  id: number;
  type: 'Scientific' | 'Engineering' | 'Policy' | 'Social';
  title: string;
  description: string;
  confidence: number;
  resources: string;
  priority: 'High' | 'Medium' | 'Low';
}

export interface DebateEntry {
  agent: 'Scientist' | 'Engineer' | 'Impact Analyst' | 'Simulation';
  dialogue: string;
}

export interface Debate {
  summary: string;
  log: DebateEntry[];
}

export interface ImpactMetric {
  label: string;
  value: number;
  unit: string;
  description: string;
}

export interface Solution {
  title: string;
  summary: string;
  blueprint: string;
  impactAnalysis: string;
  impactMetrics: ImpactMetric[];
  nextSteps: string[];
  risksAndMitigations: string[];
  nextExperiments: string[];
}

export type Stage = 'DECONSTRUCTION' | 'HYPOTHESIS' | 'DEBATE' | 'SYNTHESIS';

export type Status = 'IDLE' | 'RUNNING' | 'COMPLETED' | 'ERROR';

export interface AppState {
  problem: string;
  status: Status;
  deconstruction: ProblemDeconstruction | null;
  hypotheses: Hypothesis[];
  debate: Debate | null;
  solution: Solution | null;
  error: string | null;
  currentStage: Stage | null;
}

// Chatbot types
export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: string;
  sources?: GroundingChunk[];
}